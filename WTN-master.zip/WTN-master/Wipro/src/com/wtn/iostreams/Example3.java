package com.wtn.iostreams;

public class Example3 {

}
