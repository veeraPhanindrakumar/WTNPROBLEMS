package com.wtn.flowcontrol;

public class Example2 
{
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[0]);
		if(a%2==0)
		{
			System.out.println("Given Number is even");
		}
		else
		{
			System.out.println("Given Number is odd");	
		}
		
	}

}
