package com.wtn.flowcontrol;

public class Example4 {
	public static void main(String[] args) 
	{
		char a='s';

	    char b='e';
	if(a>b)
	{
		System.out.println(b+","+a);
	}
	else
	{
		System.out.println(a+","+b);
	}
	
	}

}
