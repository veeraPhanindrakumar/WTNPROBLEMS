package com.wtn.arrays;




import java.util.*;
public class A6 {
public static void main(String[] args) 
	{
		int[] array = {18, 8, 88, 11, 22};

		Arrays.sort(array);
		System.out.println(Arrays.toString(array));

	}

}
