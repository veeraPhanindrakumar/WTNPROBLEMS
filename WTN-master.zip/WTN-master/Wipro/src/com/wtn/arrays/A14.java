package com.wtn.arrays;

public class A14 {

	 
	public static void main(String args[])
	{
	int a=Integer.parseInt(args[0]);
	
	for(int i=0;i<=a;i++)
	{
	if(i%2==0||i%3==0|| i%5==0)
	{
	System.out.println(i);
	}
	}
	}
	}


