package com.wtn.loops;

public class Example1 {
	public static void main(String[] args) {
		
	
	int i;
	for(i=1;i<=10;i++)
	{
		
		System.out.print(i+"\t");
	}
	}
}
