package com.wtn.exception;

public class Exception4 {

}
