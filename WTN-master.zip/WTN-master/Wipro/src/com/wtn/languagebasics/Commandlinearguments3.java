package com.wtn.languagebasics;
public class Commandlinearguments3 {
	public static void main(String args[])
	{
		int a =Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.println("The Sum of "+args[0]+" "+args[1]+" is "+(a+b));
		
		
	}

}
